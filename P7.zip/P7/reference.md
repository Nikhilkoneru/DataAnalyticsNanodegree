### References:
- [Introduction to A/B Testing (Udacity)](https://www.udacity.com/course/viewer#!/c-ud120-nd)
- [Evan Miller](http://www.evanmiller.org/ab-testing/sample-size.html)
- [GraphPad](http://graphpad.com/quickcalcs/binomial1.cfm)
