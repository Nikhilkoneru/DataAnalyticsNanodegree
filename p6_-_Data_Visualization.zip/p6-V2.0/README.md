Udacity Data Analyst Nanodegree

Project 6: Make Effective Data Visualization

Summary

Here we present a visual analysis about some parameters that affects the performance of the baseball players. The dataset, provided by Udacity, contains 1,157 baseball players including their handedness (right or left handed), height (in inches), weight (in pounds), batting average, and home runs. So performance is measured as their batting average and the number of home runs; parameters are handedness, height and weight. Since height and weight are positively correlated (data not shown), we will use only height parameter. Our conclusions are: 1) smaller players are better batting; 2) medium players are more constant in their home run rates; and 3) left-handed players are better batting and doing home runs.

Design

After some exploratory data analysis, we realized that players with low height are better in their batting average. Maybe a lower center of mass helps them to performing the batting movement. Furthermore, since weight is related with height, we saw a similar tend between height and batting average (data not shown). So we decided to use only the “height” parameters and talk about player’s “size”. Other interested point was that the average number of home runs by player’s height tends to be more constant in medium players. They could have the perfect balance between height and strength to achieve home runs. So we decided that a line plot would be a good representation to show the downward trend in batting average when the height increases. We also wanted to show that there is a region of height/batting average where the average number of home runs is more constant. We though that a good representation to appreciate the “similar clusters” was to include a new dimension as the size of the dots (in this case the blue bubbles) with a radius proportional to the average number of home runs. We took into account to take the SQRT values of the average number of home runs to avoid miss-representing the areas. We used different colors two improve the contrast between the two series.

In the other hand (pun intended), we wanted to analyze if handedness was a parameter to have into account. So we decided to represent in the same plot the three groups (right, left and ambidextrous), with the average number of home runs as bar (on the left y axis) and the average of batting averages as dots (on the right y axis). Initially, we though that a bar chart would be the best choice for this type of comparison, because visually it is easy to appreciate the difference between the bar heights. So to appreciate the two series we changed their colors and their width. After some feedback we saw that it was better to use different representations. Although it is not very correct, because there is no order in categories, we decided to use a line chart for one of the series because it made the plot clearer. Doing this, we can see at a glance that left-handed players (and ambidextrous) are the best in batting, and that the left-handed are the best in home runs. In other sports, like soccer, there are similar patterns about left-footed players.

Both plots have interaction functionalities to show tooltips when we pass the mouse over the dots/bars. These tooltips contains the specific data associated to the dot/bar.

Finally, we also wanted to find individual relationships between batting average and the number of home runs. But we discarded this because we have only the absolute number of home runs for each player, and we do not know the number of batting attempts (maybe a player has a big number of home runs because he/she has been playing many years).

Note about dataset: there are some players with batting average of 0. A batting average of zero means that this person never successfully hit the ball in their entire career. These players might have been pitchers and never went to bat. We decided to include these players in the study because we wanted to show the best groups for batting (and home runs), so it is important to take into account the possible non-hitters because maybe there is an underlying reason (it would requires further studies).

Feedback

Kotha Hemanth

What are the measurement units for the height?
What means “HR”?
Regarding first plot, does it means that with higher height players are worse in something?
It would be very helpful a title for each plot.
In the second plot, what is the meaning of the blocks and the circles?
Then, second plot is trying to tell use that left-handed are better in something, isn’t it?


nikita

Horizontal axes are off on my 13in screen, and right part of chart are cut. Is that something that you already know? I'm using Firefox. Usually just making chart wider fixes such problems.

sujita 

The application looks nice, the graphics are clear and the explanations given adequate. However, I think the author can do better at data analysis (see "Observations from the graphics" below).

Some general comments

HR and batting average are not defined. In the first graph, for very small bubbles it is quite difficult to display their associated values. The title axis "Average of player's batting averages" is confusing. In the second graph, why does the width of blue and red boxes need to be so different? If the width is not related to a numerical value, then, is confusing.

Observations form the graphs:

Smaller players are better at batting, with an optimum value at 67 inches. Then, the higher the height, the smaller the average batting, decreasing smoothly to 74 inches and then plummeting to very low values.
There is an almost homogeneous distribution of HRs across all heights, with some exceptions located at both ends: a very high value at 67 inches and a very low value at 80 inches.
Left-handed players are better at both, batting and doing HRs, but those who are also right-handed (i.e. they use both hands) are equally good at batting. In terms of doing HRs, being able to use both hands does not enhance HRs values when compared to only right- or only left-handed.

Resources

dimple.js API: https://github.com/PMSI-AlignAlytics/dimple/wiki
Title for charts: http://stackoverflow.com/questions/25416063/title-for-charts-and-axes-in-dimple-js-charts
Change color line: http://stackoverflow.com/questions/25127527/how-to-change-color-of-line-in-line-chart-using-dimple-js
Change decimal places for axis: http://stackoverflow.com/questions/22988109/dimple-js-measure-axis-values
Change tooltips: http://stackoverflow.com/questions/23406531/dimplejs-line-series-tooltip-customisation
